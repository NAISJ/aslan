import requests
import tkinter as tk
from tkinter import ttk
class MyCurrencyConverter:
    def __init__(self, main_window):

        #инициализация основного окна
        self.main_window = main_window
        self.main_window.title("Мой уникальный конвертер валют")
        
        #переменные для хранения данных
        self.amount_var = tk.DoubleVar()
        self.from_currency_var = tk.StringVar()
        self.to_currency_var = tk.StringVar()
        
        #список поддерживаемых валют
        self.currencies = ["EUR", "USD", "KZT", "GBP", "JPY", "AUD", "CAD", "CNY", "SEK", "JPY", "GEL", "EGP",
                           "CZK", "CAD", "BYN", "AED", "RUB", "INR", "BRL", "NOK"]
        
        #создание пользовательского интерфейса
        self.create_ui()
    def create_ui(self):

        #ввод суммы
        amount_label = ttk.Label(self.main_window, text="Введите сумму:")
        amount_label.grid(row=0, column=0, padx=10, pady=10)
        amount_entry = ttk.Entry(self.main_window, textvariable=self.amount_var)
        amount_entry.grid(row=0, column=1, padx=10, pady=10)

        #выбор валюты из которой конвертировать
        from_currency_label = ttk.Label(self.main_window, text="Из валюты:")
        from_currency_label.grid(row=1, column=0, padx=10, pady=10)
        from_currency_combobox = ttk.Combobox(self.main_window, textvariable=self.from_currency_var, values=self.currencies)
        from_currency_combobox.grid(row=1, column=1, padx=10, pady=10)
        from_currency_combobox.set("EUR")

        #выбор валюты в которую конвертировать
        to_currency_label = ttk.Label(self.main_window, text="В валюту:")
        to_currency_label.grid(row=2, column=0, padx=10, pady=10)
        to_currency_combobox = ttk.Combobox(self.main_window, textvariable=self.to_currency_var, values=self.currencies)
        to_currency_combobox.grid(row=2, column=1, padx=10, pady=10)
        to_currency_combobox.set("USD")

        #кнопка для конвертации
        convert_button = ttk.Button(self.main_window, text="Конвертировать", command=self.convert_currency)
        convert_button.grid(row=3, column=0, columnspan=2, pady=10)

        #отображение результата
        self.result_var = tk.StringVar()
        result_label = ttk.Label(self.main_window, textvariable=self.result_var, font=("Helvetica", 16))
        result_label.grid(row=4, column=0, columnspan=2, pady=10)
    def convert_currency(self):

        #получение данных из полей ввода
        amount = self.amount_var.get()
        from_currency = self.from_currency_var.get()
        to_currency = self.to_currency_var.get()

        #проверка на отрицательную сумму
        if amount < 0:
            self.result_var.set("Ошибка: Введите положительную сумму")
            return

        #проверка на заполненность полей
        if amount and from_currency and to_currency:
            # Получение курса конвертации и вычисление результата
            conversion_rate = self.get_conversion_rate(from_currency, to_currency)
            converted_amount = round(amount * conversion_rate, 2)
            result_text = f"{amount} {from_currency} = {converted_amount} {to_currency}"
            self.result_var.set(result_text)
        else:
            self.result_var.set("Заполните все поля")
    def get_conversion_rate(self, from_currency, to_currency):

        #получение курса конвертации из API
        api_key = "e62d7002d65fdf81318b81ff"
        url = f"https://open.er-api.com/v6/latest/{from_currency}"
        try:
            response = requests.get(url)
            data = response.json()
            conversion_rate = data["rates"][to_currency]
            return conversion_rate
        except requests.RequestException as e:
            print(f"Ошибка при получении данных: {e}")
            return 0.0
if __name__ == "__main__":

    #создание основного окна и запуск приложения
    root = tk.Tk()
    app = MyCurrencyConverter(root)
    root.mainloop()